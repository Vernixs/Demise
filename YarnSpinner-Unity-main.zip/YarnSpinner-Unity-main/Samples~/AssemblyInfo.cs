﻿using System.Reflection;

[assembly: AssemblyVersion("2.0.2.0")]

[assembly: AssemblyFileVersion("2.0.2.0")]
[assembly: AssemblyInformationalVersion("2.0.2-development")]
