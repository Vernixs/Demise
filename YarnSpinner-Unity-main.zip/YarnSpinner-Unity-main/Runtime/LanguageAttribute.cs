using UnityEngine;

namespace Yarn.Unity
{
    public class LanguageAttribute : PropertyAttribute
    {
        // No data or methods on this attribute; it's purely a marker.
    }
}
